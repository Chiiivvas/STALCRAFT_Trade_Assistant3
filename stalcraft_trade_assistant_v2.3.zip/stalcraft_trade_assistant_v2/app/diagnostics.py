"""Диагностика: наложение на кадр, отчёт, сохранение проблемных кадров для разбора."""
from __future__ import annotations

import json
import time
from pathlib import Path

import cv2
import numpy as np

from .models import CHECK, OK, PENDING, STATUS_TEXT, UNRECOGNIZED, ScanResult
from .paths import data_dir
from .price_database import imwrite_unicode

_COLORS = {OK: (90, 217, 149), CHECK: (60, 170, 255), UNRECOGNIZED: (80, 80, 255), PENDING: (255, 183, 127)}


def render_overlay(result: ScanResult) -> np.ndarray | None:
    """Кадр области с РЕАЛЬНЫМИ границами найденных клеток и линий сетки (подписи — латиницей)."""
    if result.right_img is None:
        return None
    img = result.right_img.copy()
    H, W = img.shape[:2]
    g = result.grid
    if g is not None:
        for x in g.xlines:                                   # найденные линии сетки
            cv2.line(img, (int(round(x)), 0), (int(round(x)), H - 1), (255, 200, 0), 1)
        for y in g.ylines:
            cv2.line(img, (0, int(round(y))), (W - 1, int(round(y))), (255, 200, 0), 1)
        for c in g.cells:                                    # границы каждой клетки
            col = (0, 165, 255) if c.partial else (170, 170, 170)
            cv2.rectangle(img, (c.x, c.y), (c.x + c.w - 1, c.y + c.h - 1), col, 1)
            cv2.putText(img, f"{c.row + 1}:{c.col + 1}", (c.x + 2, c.y + 10), cv2.FONT_HERSHEY_SIMPLEX,
                        0.3, col, 1, cv2.LINE_AA)
        if g.bounds:
            x0, y0, x1, y1 = g.bounds
            cv2.rectangle(img, (x0, y0), (min(x1, W - 1), min(y1, H - 1)), (255, 120, 0), 1)
        if g.reliable:
            txt = (f"GRID OK {g.columns}x{g.rows} pitch {g.pitch_x:.1f}x{g.pitch_y:.1f} "
                   f"overlaps: {'NONE' if not g.problems else len(g.problems)}")
            colr = (90, 217, 149) if not g.problems else (60, 60, 255)
        else:
            txt, colr = "GRID UNRELIABLE - recognition disabled", (60, 60, 255)
            cv2.rectangle(img, (0, 0), (W - 1, H - 1), colr, 3)
        cv2.rectangle(img, (0, 0), (min(W, 420), 16), (0, 0, 0), -1)
        cv2.putText(img, txt, (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.42, colr, 1, cv2.LINE_AA)
    for card in result.cards:
        x, y, w, h = card.rect
        color = _COLORS.get(card.status, (200, 200, 200))
        cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), color, 2)
        label = f"{card.icon_id or '?'} x{card.qty if card.qty is not None else '?'}"
        cv2.putText(img, label, (x + 3, y + h - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1, cv2.LINE_AA)
    return img


def grid_report(result: ScanResult) -> dict | None:
    g = result.grid
    if g is None:
        return None
    return {"reliable": g.reliable, "warning": g.warning, "problems": g.problems, "method": g.method,
            "pitch": [round(g.pitch_x, 2), round(g.pitch_y, 2)],
            "xlines": [round(v, 1) for v in g.xlines], "ylines": [round(v, 1) for v in g.ylines],
            "bounds": list(g.bounds) if g.bounds else None, "region_size": list(g.region_size),
            "cells": [{"row": c.row + 1, "col": c.col + 1, "rect": list(c.rect),
                       "partial": c.partial, "filled": c.filled} for c in g.cells]}


def report_dict(result: ScanResult) -> dict:
    return {
        "elapsed_ms": round(result.elapsed_ms, 1),
        "stage": result.stage, "seq": result.seq,
        "timings_ms": result.timings.as_dict(),
        "errors": result.errors,
        "notes": result.notes,
        "grid": grid_report(result),
        "cards": [{
            "row": c.row, "col": c.col, "partial": c.partial, "status": c.status,
            "icon_id": c.icon_id, "icon_confident": c.icon_confident,
            "icon_score": round(c.raw.icon.best_score, 3) if c.raw else None,
            "icon_margin": round(c.raw.icon.margin, 3) if c.raw else None,
            "icon_scores": ({k: round(v, 3) for k, v in c.raw.icon.scores.items()} if c.raw else None),
            "qty": c.qty, "qty_raw": c.raw.qty.raw if c.raw else None,
            "qty_votes": c.raw.qty.votes if c.raw else None,
            "weight": c.raw.weight.value if c.raw and c.raw.weight else None,
            "weight_raw": c.raw.weight.raw if c.raw and c.raw.weight else None,
            "weight_consistent": c.weight_consistent, "reasons": c.reasons,
        } for c in result.cards],
        "items": [{
            "key": i.key, "name": i.name, "qty": i.qty, "price": i.price,
            "status": i.status, "status_text": STATUS_TEXT[i.status],
            "confirmed_by": i.confirmed_by, "reasons": i.reasons,
        } for i in result.items],
        "list": ({"totals": result.list_reading.totals,
                  "ambiguous": sorted(result.list_reading.ambiguous),
                  "unknown_lines": result.list_reading.unknown_lines,
                  "header_weight": result.list_reading.header_weight,
                  "raw_texts": result.list_reading.raw_texts}
                 if result.list_reading else None),
    }


def save_problem(result: ScanResult, note: str = "", root: Path | None = None) -> Path:
    """Сохраняет кадры + отчёт. Всё остаётся локально, наружу ничего не отправляется."""
    root = root or (data_dir() / "problems")
    folder = root / time.strftime("%Y%m%d_%H%M%S")
    folder.mkdir(parents=True, exist_ok=True)
    if result.right_img is not None:
        imwrite_unicode(folder / "right_region.png", result.right_img)
    if result.left_img is not None:
        imwrite_unicode(folder / "left_region.png", result.left_img)
    for c in result.cards:
        if c.cell is not None:
            imwrite_unicode(folder / "cards" / f"r{c.row + 1}c{c.col + 1}_{c.status}.png", c.cell)
    rep = report_dict(result)
    rep["note"] = note
    (folder / "report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    return folder
