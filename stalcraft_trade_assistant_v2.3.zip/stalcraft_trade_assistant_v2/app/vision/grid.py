"""Поиск сетки слотов обмена по РЕАЛЬНЫМ линиям, а не делением области на равные части.

Алгоритм:
  1. Тонкие тёмные линии выделяются морфологически (закрытие «заливает» узкие тёмные полосы,
     разность с оригиналом = глубина линии), затем оставляются только ДЛИННЫЕ непрерывные
     отрезки — текст, иконки и значки таких линий не дают.
  2. Среди вертикальных линий ищется самая длинная ПРАВИЛЬНАЯ прогрессия (равный шаг).
     Список «Вы получите», заголовок, соседние панели и инвентарь в неё не попадают.
  3. Горизонтальные линии ищутся только внутри найденного диапазона колонок, с шагом,
     связанным с шириной ячейки (в игре отношение постоянно).
  4. Границы клеток — это найденные линии: клетки не пересекаются и не обрезают содержимое.
  5. Если сетка ненадёжна (мало линий, нерегулярный шаг, несколько сеток, пересечения) —
     grid.reliable = False, клетки не возвращаются и распознавание не выполняется.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

from . import layout

MIN_RUN_V = 30            # минимальная длина непрерывной вертикальной линии, px
MIN_LINES_X = 4           # минимум линий для надёжной сетки (3 колонки)
MAX_RESIDUAL = 1.8        # допустимое отклонение линий от прогрессии, px
MIN_PITCH = 24.0
EDGE_SLACK = 0.12         # допуск на «дрожание» выбора области мышью (доли шага)
AMBIGUOUS_MIN_LINES = 6   # столько линий во «второй» сетке = в области две сетки


@dataclass
class Cell:
    row: int
    col: int
    x: int
    y: int
    w: int
    h: int
    partial: bool = False   # слот виден не целиком (обрезан областью или интерфейсом игры)
    filled: bool = False    # в слоте есть предмет

    @property
    def rect(self) -> tuple[int, int, int, int]:
        return self.x, self.y, self.w, self.h


@dataclass
class Grid:
    cells: list[Cell] = field(default_factory=list)
    pitch_x: float = 0.0
    pitch_y: float = 0.0
    method: str = "lines"          # lines | none
    notes: list[str] = field(default_factory=list)
    reliable: bool = False
    warning: str = ""
    xlines: list[float] = field(default_factory=list)   # позиции вертикальных линий (в координатах области)
    ylines: list[float] = field(default_factory=list)   # позиции горизонтальных линий
    bounds: tuple[int, int, int, int] | None = None     # (x0, y0, x1, y1) найденной сетки
    problems: list[str] = field(default_factory=list)   # результат проверки (пересечения, размеры)
    region_size: tuple[int, int] = (0, 0)

    def filled_cells(self) -> list[Cell]:
        return [c for c in self.cells if c.filled]

    @property
    def columns(self) -> int:
        return len({c.col for c in self.cells})

    @property
    def rows(self) -> int:
        return len({c.row for c in self.cells})


# ---------------------------------------------------------------- линии -----
def _depth_threshold(gray: np.ndarray) -> float:
    return max(8.0, 0.15 * float(np.percentile(gray, 60)))


def _score_vertical_lines(gray: np.ndarray, depth: float) -> tuple[np.ndarray, np.ndarray]:
    """Для каждого столбца — суммарная длина длинных непрерывных тёмных вертикальных отрезков
    (и сама маска таких отрезков — по ней определяется верх и низ сетки)."""
    closed = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, np.ones((1, 5), np.uint8))
    mask = ((closed.astype(np.int16) - gray) >= depth).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((7, 1), np.uint8))
    h = gray.shape[0]
    run = min(MIN_RUN_V, max(8, h // 2))
    opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((run, 1), np.uint8))
    return opened.sum(axis=0).astype(np.float32), opened


def _score_horizontal_lines(gray: np.ndarray, depth: float, min_run: int) -> np.ndarray:
    closed = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, np.ones((5, 1), np.uint8))
    mask = ((closed.astype(np.int16) - gray) >= depth).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((1, 7), np.uint8))
    opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((1, max(8, min_run)), np.uint8))
    return opened.sum(axis=1).astype(np.float32)


def _centers(score: np.ndarray, min_len: float) -> tuple[list[float], list[float]]:
    """Центры групп соседних индексов с длинной линией и их «вес» (длина)."""
    idx = np.where(score >= min_len)[0]
    groups: list[list[int]] = []
    for i in idx:
        if groups and i - groups[-1][-1] <= 2:
            groups[-1].append(int(i))
        else:
            groups.append([int(i)])
    cs, ws = [], []
    for g in groups:
        w = score[g]
        core = w >= 0.6 * w.max()                 # «звон» по краям линии в центр не входит
        idx_g, w_core = np.array(g)[core], w[core]
        cs.append(float((idx_g * w_core).sum() / w_core.sum()))
        ws.append(float(w.max()))
    return cs, ws


@dataclass
class _Prog:
    positions: list[float]
    pitch: float
    residual: float
    weight: float


def _best_progression(centers: list[float], weights: list[float],
                      pitch_range: tuple[float, float] | None = None,
                      max_lines: int | None = None) -> _Prog | None:
    """Самая длинная последовательность линий с ПОЧТИ равным шагом (подряд, без пропусков)."""
    n = len(centers)
    if n < 2:
        return None
    best: tuple[int, float] | None = None
    best_prog: _Prog | None = None
    seen: set[tuple[int, int]] = set()
    for i in range(n):
        for j in range(i + 1, n):
            d = centers[j] - centers[i]
            if d < MIN_PITCH:
                continue
            for k in (1, 2, 3):
                p = d / k
                if p < MIN_PITCH or (pitch_range and not pitch_range[0] <= p <= pitch_range[1]):
                    continue
                key = (i, int(round(p * 2)))
                if key in seen:
                    continue
                seen.add(key)
                tol = max(2.2, 0.035 * p)
                matched: dict[int, int] = {}
                for step in range(-12, 13):
                    pos = centers[i] + step * p
                    cand = [m for m in range(n) if abs(centers[m] - pos) <= tol]
                    if cand:
                        matched[step] = min(cand, key=lambda m: abs(centers[m] - pos))
                # самая длинная серия шагов, содержащая шаг 0; допускается ОДИН пропущенный шаг
                # между найденными линиями (недостающая линия достраивается по прогрессии)
                if 0 not in matched:
                    continue
                lo = hi = 0
                while True:
                    if lo - 1 in matched:
                        lo -= 1
                    elif lo - 2 in matched:
                        lo -= 2
                    else:
                        break
                while True:
                    if hi + 1 in matched:
                        hi += 1
                    elif hi + 2 in matched:
                        hi += 2
                    else:
                        break
                idxs: list[int] = []
                for st in range(lo, hi + 1):
                    idxs.append(matched[st] if st in matched else -1)
                real = [m for m in idxs if m >= 0]
                if max_lines and len(idxs) > max_lines:
                    wins = [(sum(weights[m] for m in idxs[a:a + max_lines] if m >= 0), a)
                            for a in range(len(idxs) - max_lines + 1)]
                    a = max(wins)[1]
                    idxs = idxs[a:a + max_lines]
                    real = [m for m in idxs if m >= 0]
                if len(real) < 2:
                    continue
                score = (len(real), sum(weights[m] for m in real))
                if best is None or score > best:
                    t_all = np.arange(len(idxs), dtype=np.float64)
                    t_real = np.array([k for k, m in enumerate(idxs) if m >= 0], dtype=np.float64)
                    pos_real = np.array([centers[m] for m in idxs if m >= 0])
                    pitch, c0 = np.polyfit(t_real, pos_real, 1)
                    res = float(np.max(np.abs(pos_real - (c0 + pitch * t_real))))
                    # недостающие линии берём из прогрессии, найденные — как есть
                    pos_list = [centers[m] if m >= 0 else float(c0 + pitch * k) for k, m in enumerate(idxs)]
                    best = score
                    best_prog = _Prog(pos_list, float(pitch), res, score[1])
    return best_prog


# ---------------------------------------------------------------- проверка ----
def validate_grid(grid: Grid) -> list[str]:
    """Проверка: клетки внутри области, не пересекаются, размеры согласованы."""
    problems: list[str] = []
    W, H = grid.region_size
    cs = grid.cells
    for c in cs:
        if c.x < 0 or c.y < 0 or c.x + c.w > W or c.y + c.h > H:
            problems.append(f"клетка {c.row + 1}:{c.col + 1} выходит за область")
    for i in range(len(cs)):
        a = cs[i]
        for b in cs[i + 1:]:
            if a.x < b.x + b.w and b.x < a.x + a.w and a.y < b.y + b.h and b.y < a.y + a.h:
                problems.append(f"клетки {a.row + 1}:{a.col + 1} и {b.row + 1}:{b.col + 1} пересекаются")
    full = [c for c in cs if not c.partial]
    if full:
        tol_w = max(3.0, 0.06 * grid.pitch_x)          # округление линий при дробном шаге
        tol_h = max(3.0, 0.06 * grid.pitch_y)
        if max(c.w for c in full) - min(c.w for c in full) > tol_w:
            problems.append("ширина клеток неодинакова")
        if max(c.h for c in full) - min(c.h for c in full) > tol_h:
            problems.append("высота клеток неодинакова")
    return problems


def _unreliable(grid: Grid, msg: str) -> Grid:
    grid.reliable = False
    grid.cells = []
    grid.method = "none"
    grid.warning = ("Сетка предметов определена ненадёжно: " + msg +
                    ". Выделите область заново: только сетку предметов партнёра, "
                    "без заголовка, списка «Вы получите» и других панелей.")
    return grid


# ---------------------------------------------------------------- основное ---
@dataclass
class _Lines:
    xs: list[float]
    ys: list[float]
    pitch_x: float
    pitch_y: float
    notes: list[str]
    y_top: float = 0.0              # верх сетки по вертикальным линиям
    y_bot: float = 0.0              # низ сетки по вертикальным линиям (игра обрезает сетку)
    anchored: bool = False          # строки привязаны к верху вертикальных линий


def _find_rows(sub: np.ndarray, pitch_x: float, depth: float, y_top: float, y_bot: float):
    """Строки сетки: гребёнка с шагом ≈ pitch_x * CELL_ASPECT по устойчивому профилю глубины.

    Профиль — медиана глубины тёмных горизонтальных линий по ширине сетки: содержимое карточек
    (иконки, текст) на медиану не влияет, а линии сетки проходят через всю ширину.
    Возвращает (позиции линий, шаг, найдена_одна_линия) или None.
    """
    h = sub.shape[0]
    closed = cv2.morphologyEx(sub, cv2.MORPH_CLOSE, np.ones((5, 1), np.uint8))
    prof = np.median(closed.astype(np.int16) - sub, axis=1).astype(np.float64)
    if h < 8 or float(prof.max()) < 0.4 * depth:
        return None
    exp = pitch_x * layout.CELL_ASPECT
    pk = np.maximum.reduce([prof, np.roll(prof, 1), np.roll(prof, -1)])        # допуск ±1 px
    cap = max(6.0, float(np.percentile(prof, 99)))
    cands: list[tuple[float, float, float]] = []
    ys_idx = np.arange(h, dtype=np.float64)
    vals = np.minimum(pk, cap) / cap
    for p in np.arange(exp * 0.95, exp * 1.05 + 1e-6, 0.25):
        # сворачиваем профиль по остатку от деления на шаг: максимум = фаза гребёнки
        bins = int(np.ceil(p)) + 1
        idx = np.round(np.mod(ys_idx, p)).astype(np.int64) % bins
        acc = np.bincount(idx, weights=vals, minlength=bins)
        acc = acc + 0.5 * (np.roll(acc, 1) + np.roll(acc, -1))          # допуск на дробный шаг
        j = int(np.argmax(acc))
        ph = float(j) if j <= 0.85 * p else float(j) - p                # фаза в диапазоне [-0.15p, 0.85p]
        cands.append((float(acc[j]), float(p), ph))
    if not cands:
        return None
    top_score = max(c[0] for c in cands)
    # близкие по счёту шаги неразличимы (75 vs 76) — берём ближайший к ожидаемому из ширины ячейки
    p, ph = min(((c[1], c[2]) for c in cands if c[0] >= 0.97 * top_score), key=lambda t: abs(t[0] - exp))

    # реальные линии: зубья гребёнки с опорой в профиле, положение уточняется по локальному пику
    teeth = [(k, ph + k * p) for k in range(-1, int((h - ph) / p) + 2)]
    ks_ref, ys_ref = [], []
    for k, y in teeth:
        yi = int(round(y))
        if 3 <= yi <= h - 4 and pk[yi] >= 0.4 * depth:
            lo_i, hi_i = max(1, yi - 2), min(h - 1, yi + 3)
            m = lo_i + int(np.argmax(prof[lo_i:hi_i]))          # пик профиля (+ параболическая поправка)
            l_, c_, r_ = prof[m - 1], prof[m], prof[min(m + 1, h - 1)]
            den = l_ - 2 * c_ + r_
            off = 0.5 * (l_ - r_) / den if den < -1e-6 else 0.0
            ks_ref.append(k)
            ys_ref.append(float(m + max(-0.5, min(0.5, off))))
    c0 = ph                                              # положение линии k = 0
    if ks_ref:
        # отношение высоты к ширине ячейки в игре постоянно, поэтому шаг фиксируем (он точнее шумных
        # пиков), а подбираем только смещение; свободный шаг — лишь если фиксированный не ложится на линии
        offs = [y - k * exp for k, y in zip(ks_ref, ys_ref)]
        c_fixed = float(np.median(offs))
        resid = max(abs(y - (c_fixed + k * exp)) for k, y in zip(ks_ref, ys_ref))
        if resid <= 1.5:
            p, c0 = float(exp), c_fixed
        elif len(ks_ref) >= 2:
            p_fit, c_fit = np.polyfit(ks_ref, ys_ref, 1)
            if abs(p_fit - exp) <= 0.07 * exp:
                p, c0 = float(p_fit), float(c_fit)
        else:
            c0 = ys_ref[0] - ks_ref[0] * p
    # верх сетки известен по вертикальным линиям; если линий у строк нет — берём его как якорь,
    # а если вертикальные линии упираются в верх области (сетка обрезана выделением) — фазу гребёнки
    anchored = y_top > 2.0
    if anchored and len(ks_ref) < 2:
        c0 = float(y_top)
    elif anchored:
        # ближайшая к верху вертикальных линий линия гребёнки
        kk = round((y_top - c0) / p)
        if abs(c0 + kk * p - y_top) <= 3.0:
            c0 = c0 + kk * p
        else:
            c0 = float(y_top)
    else:
        kk = int(np.floor((-0.15 * p - c0) / p)) + 1       # первая линия не выше -0.15p
        c0 = c0 + kk * p
    lim = min(y_bot, h - 1) + 0.25 * p
    ys = []
    k = 0
    while c0 + k * p <= lim and k < 200:
        ys.append(float(c0 + k * p))
        k += 1
    if not ys:
        return None
    return ys, float(p), len(ys) == 1, anchored


def _find_lines(gray: np.ndarray) -> tuple[_Lines | None, str]:
    """Находит линии сетки. Возвращает (линии, "") или (None, причина ненадёжности)."""
    h, w = gray.shape
    depth = _depth_threshold(gray)
    notes: list[str] = []

    # --- вертикальные линии ---------------------------------------------------
    vscore, vmask = _score_vertical_lines(gray, depth)
    run = min(MIN_RUN_V, max(8, h // 2))
    vc, vw = _centers(vscore, run)
    if vw:
        # линии сетки заметно длиннее ложных (края иконок, артефакты ресайза) — оставляем только длинные
        keep = [i for i, wt in enumerate(vw) if wt >= 0.5 * max(vw)]
        vc, vw = [vc[i] for i in keep], [vw[i] for i in keep]
        # и только реально тёмные: ложные «линии» (промежуточные, звон ресайза) на всём протяжении
        # почти не темнее фона и иначе образовали бы прогрессию вдвое меньшего шага
        keep = []
        for i, c in enumerate(vc):
            xi = int(round(c))
            if xi < 5 or xi > w - 6:
                keep.append(i)                         # у самого края область не позволяет проверить
                continue
            on = np.where(vmask[:, max(0, xi - 1):xi + 2].max(axis=1) > 0)[0]
            if on.size < 4:
                continue
            a, b = int(on[0]), int(on[-1]) + 1
            core = gray[a:b, xi - 1:xi + 2].min(axis=1).mean()
            side = 0.5 * (gray[a:b, xi - 5:xi - 3].mean() + gray[a:b, xi + 4:xi + 6].mean())
            if side - core >= 0.5 * depth:
                keep.append(i)
        vc, vw = [vc[i] for i in keep], [vw[i] for i in keep]
    prog = _best_progression(vc, vw, max_lines=layout.GRID_COLUMNS + 1)
    if prog is None or len(prog.positions) < MIN_LINES_X:
        n = 0 if prog is None else len(prog.positions)
        return None, f"найдено только {n} вертикальных линий сетки"
    if prog.residual > MAX_RESIDUAL:
        return None, "вертикальные линии расположены нерегулярно"
    # две одинаковые сетки в области (например, партнёр и инвентарь) — неоднозначно
    span = (prog.positions[0] - prog.pitch, prog.positions[-1] + prog.pitch)
    rest = [(c, wt) for c, wt in zip(vc, vw) if not span[0] <= c <= span[1]]
    if rest:
        other = _best_progression([c for c, _ in rest], [wt for _, wt in rest],
                                  pitch_range=(prog.pitch * 0.95, prog.pitch * 1.05))
        if other is not None and len(other.positions) >= AMBIGUOUS_MIN_LINES:
            return None, "в области найдено несколько сеток"

    pitch_x = prog.pitch
    xs = list(prog.positions)
    # линии, оказавшиеся чуть за краем области из-за дрожания мыши
    while len(xs) < layout.GRID_COLUMNS + 1 and xs[0] - pitch_x >= -EDGE_SLACK * pitch_x:
        xs.insert(0, xs[0] - pitch_x)
    while len(xs) < layout.GRID_COLUMNS + 1 and xs[-1] + pitch_x <= w + EDGE_SLACK * pitch_x:
        xs.append(xs[-1] + pitch_x)

    # --- горизонтальные линии (только внутри сетки по ширине) --------------------------
    ix0, ix1 = max(0, int(round(xs[0]))), min(w, int(round(xs[-1])) + 1)
    sub = gray[:, ix0:ix1]
    tops, bots = [], []
    for x in prog.positions:
        xi = int(round(x))
        col = vmask[:, max(0, xi - 1):min(w, xi + 2)].max(axis=1) > 0
        on = np.where(col)[0]
        if on.size:
            tops.append(int(on[0]))
            bots.append(int(on[-1]))
    if not tops:
        return None, "не удалось определить верх и низ сетки"
    y_top, y_bot = float(np.median(tops)), float(np.median(bots))
    found = _find_rows(sub, pitch_x, depth, y_top, y_bot)
    if found is None:
        return None, "горизонтальные линии сетки не найдены"
    ys, pitch_y, single, anchored = found
    if single:
        notes.append("найдена одна горизонтальная линия сетки, шаг по высоте вычислен по ширине ячейки")
    if ys[0] > 0.35 * pitch_y:
        notes.append(f"над первой линией сетки осталась полоса {int(ys[0])} px (заголовок или обрезанная карточка)")
    lines = _Lines(xs, ys, pitch_x, pitch_y, notes, y_top, y_bot, anchored)
    # финальная проверка: каждая линия прогрессии (в т.ч. достроенная) реально есть в кадре
    if not _lines_still_present(gray, lines):
        return None, "часть линий сетки не подтверждена в кадре"
    return lines, ""


def _lines_still_present(gray: np.ndarray, ln: _Lines) -> bool:
    """Дешёвая проверка (доли мс): закэшированные линии всё ещё на месте."""
    h, w = gray.shape
    depth = _depth_threshold(gray)
    y0, y1 = max(0, int(ln.ys[0])), min(h, int(ln.ys[-1] + ln.pitch_y))
    x0, x1 = max(0, int(ln.xs[0])), min(w, int(ln.xs[-1]))
    if y1 - y0 < 8 or x1 - x0 < 8:
        return False
    for x in ln.xs:
        xi = int(round(x))
        if xi < 4 or xi > w - 5:
            continue                                   # линия у самого края области — не проверяем
        core = gray[y0:y1, xi - 1:xi + 2].min(axis=1).mean()
        side = 0.5 * (gray[y0:y1, xi - 5:xi - 3].mean() + gray[y0:y1, xi + 4:xi + 6].mean())
        if side - core < 0.5 * depth:
            return False
    for y in ln.ys:
        yi = int(round(y))
        if yi < 4 or yi > h - 5:
            continue
        if ln.anchored and abs(y - ln.y_top) <= 3.0:
            continue                                   # верхняя граница подтверждена вертикальными линиями
        core = gray[yi - 1:yi + 2, x0:x1].min(axis=0).mean()
        side = 0.5 * (gray[yi - 5:yi - 3, x0:x1].mean() + gray[yi + 4:yi + 6, x0:x1].mean())
        if side - core < 0.5 * depth:
            return False
    return True


def _build_grid(region_bgr: np.ndarray, ln: _Lines) -> Grid:
    h, w = region_bgr.shape[:2]
    grid = Grid(region_size=(w, h), pitch_x=ln.pitch_x, pitch_y=ln.pitch_y, notes=list(ln.notes))
    xs, ys, pitch_x, pitch_y = ln.xs, ln.ys, ln.pitch_x, ln.pitch_y
    grid.xlines, grid.ylines = list(xs), list(ys)
    grid.bounds = (int(round(xs[0])), int(round(ys[0])), int(round(xs[-1])), int(round(ys[-1] + pitch_y)))
    y_end = min(ln.y_bot + 1.0, float(h)) if ln.y_bot > ys[0] else float(h)   # игра обрезает сетку здесь
    rows: list[tuple[float, float, bool]] = [(a, b, False) for a, b in zip(ys, ys[1:]) if b <= y_end + 0.25 * pitch_y]
    last = ys[-1] if not rows else rows[-1][1]
    vis = (min(last + pitch_y, y_end) - last) / pitch_y
    if vis >= 0.35:                                  # нижняя строка обрезана интерфейсом/областью
        rows.append((last, min(last + pitch_y, y_end), vis < 0.88))
    hsv_v = cv2.cvtColor(region_bgr, cv2.COLOR_BGR2HSV)[..., 2]      # яркость V
    for r, (ya, yb, part_y) in enumerate(rows):
        for c, (xa, xb) in enumerate(zip(xs, xs[1:])):
            # граница клетки = найденная линия; у края области прижимаем, а не выбрасываем клетку
            x, y = max(0, int(round(xa)) + 1), max(0, int(round(ya)) + 1)
            cw, ch = min(int(round(xb)) - 1, w) - x, min(int(round(yb)) - 1, h) - y
            if cw < 8 or ch < 8:
                continue
            part_x = (xa < -EDGE_SLACK * pitch_x) or (xb > w + EDGE_SLACK * pitch_x)
            cell = Cell(r, c, x, y, cw, ch, partial=part_y or part_x or yb - ya < 0.88 * pitch_y)
            v = hsv_v[y:y + ch, x:x + cw]
            cell.filled = float((v > layout.FILLED_BRIGHT_V).mean()) >= layout.FILLED_MIN_FRACTION
            grid.cells.append(cell)
    grid.reliable = True
    grid.method = "lines"
    grid.problems = validate_grid(grid)
    if grid.problems:
        return _unreliable(grid, "; ".join(grid.problems[:2]))
    if not grid.cells:
        return _unreliable(grid, "не удалось построить ни одной клетки")
    return grid


class GridDetector:
    """Определение сетки с кэшем линий: пока линии на месте, повторный поиск не нужен."""

    def __init__(self) -> None:
        self._lines: _Lines | None = None
        self._shape: tuple[int, int] | None = None

    def reset(self) -> None:
        self._lines = None
        self._shape = None

    def detect(self, region_bgr: np.ndarray) -> Grid:
        h, w = region_bgr.shape[:2]
        gray = cv2.cvtColor(region_bgr, cv2.COLOR_BGR2GRAY)
        if self._lines is not None and self._shape == (h, w) and _lines_still_present(gray, self._lines):
            return _build_grid(region_bgr, self._lines)
        ln, why = _find_lines(gray)
        if ln is None:
            self.reset()
            return _unreliable(Grid(region_size=(w, h)), why)
        grid = _build_grid(region_bgr, ln)
        if grid.reliable:
            self._lines, self._shape = ln, (h, w)
        else:
            self.reset()
        return grid


def detect_grid(region_bgr: np.ndarray) -> Grid:
    """Одноразовое определение сетки (без кэша)."""
    return GridDetector().detect(region_bgr)
