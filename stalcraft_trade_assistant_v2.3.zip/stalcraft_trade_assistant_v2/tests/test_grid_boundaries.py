"""Границы карточек: по реальным линиям сетки, без пересечений, без захвата заголовков/списка.

Кадр — реальный скриншот пользователя (STALCRAFT, 1920x1080) с ошибочной диагностикой:
широкая область выделения захватывала список «Вы получите», заголовок и инвентарь.
"""
import json, pathlib, random, time
import cv2, numpy as np, pytest

from .conftest import crop
from app.diagnostics import grid_report, render_overlay
from app.models import ScanResult
from app.vision.grid import Cell, Grid, GridDetector, detect_grid, validate_grid

FIX = pathlib.Path(__file__).parent / "fixtures"
GX = [323 + 74 * k for k in range(9)]            # вертикальные линии сетки партнёра (координаты игры)
GY = [598, 674, 750, 826]                        # горизонтальные линии
GRID_BOTTOM = 858                                # здесь игра обрезает сетку
FILLED = {(0, c) for c in range(8)} | {(1, c) for c in (0, 1, 2, 4, 5, 6, 7)}   # слот 2:4 — замок

REGIONS = {
    "user_wide (список+заголовок+инвентарь)": (28, 572, 1140, 353),
    "tight": (323, 598, 594, 260),
    "loose": (300, 560, 660, 330),
    "with_list_left": (90, 560, 840, 330),
    "offset3": (326, 601, 590, 257),
}


@pytest.fixture(scope="module")
def lk():
    return cv2.imread(str(FIX / "trade_likkira_overlay.png"))


def game_rects(g, x0, y0):
    return {(c.row, c.col): (c.x + x0, c.y + y0, c.w, c.h) for c in g.cells}


@pytest.mark.parametrize("name", list(REGIONS))
def test_cells_follow_real_grid_lines(lk, name):
    x0, y0, w, h = REGIONS[name]
    g = detect_grid(crop(lk, REGIONS[name]))
    assert g.reliable and g.columns == 8 and g.rows == 4, g.warning
    assert {(c.row, c.col) for c in g.filled_cells()} == FILLED
    for (r, c), (x, y, cw, ch) in game_rects(g, x0, y0).items():
        tol = 3 if (x == x0 or y == y0) else 1          # клетка у края области прижата к нему
        assert abs(x - (GX[c] + 1)) <= tol and abs(y - (GY[r] + 1)) <= tol, (name, r, c, x, y)
        if r < 3 and tol == 1:
            assert abs(cw - 72) <= 1 and abs(ch - 74) <= 1
    # нижняя строка обрезана игрой: она помечена partial и не заходит на кнопку «Отменить обмен»
    last = [c for c in g.cells if c.row == 3]
    assert last and all(c.partial for c in last)
    assert all(c.y + y0 + c.h <= GRID_BOTTOM + 1 for c in last)


@pytest.mark.parametrize("name", list(REGIONS))
def test_cells_never_overlap_and_stay_inside_grid(lk, name):
    x0, y0, _w, _h = REGIONS[name]
    g = detect_grid(crop(lk, REGIONS[name]))
    assert g.reliable and validate_grid(g) == [] and g.problems == []
    for (_r, _c), (x, y, cw, ch) in game_rects(g, x0, y0).items():
        assert x >= GX[0] and x + cw <= GX[-1] + 1 and y >= GY[0] and y + ch <= GRID_BOTTOM + 1


def test_header_list_and_inventory_are_not_captured(lk):
    x0, y0, *_ = REGIONS["user_wide (список+заголовок+инвентарь)"]
    g = detect_grid(crop(lk, REGIONS["user_wide (список+заголовок+инвентарь)"]))
    xs = [c.x + x0 for c in g.cells]
    ys = [c.y + y0 for c in g.cells]
    assert min(xs) >= 323 and max(c.x + c.w + x0 for c in g.cells) <= 916     # ни списка слева, ни инвентаря справа
    assert min(ys) >= 598                                                     # ни заголовка «LikKira», ни «Группировать»


def test_region_jitter_never_shifts_cells(lk):
    rnd = random.Random(7)
    for _ in range(40):
        x0, y0 = rnd.randint(60, 326), rnd.randint(540, 601)
        x1, y1 = rnd.randint(918, 1005), rnd.randint(860, 930)
        g = detect_grid(lk[y0:y1, x0:x1])
        assert g.reliable, (x0, y0, x1, y1, g.warning)
        assert {(c.row, c.col) for c in g.filled_cells()} == FILLED, (x0, y0, x1, y1)
        for (r, c), (x, y, *_s) in game_rects(g, x0, y0).items():
            assert abs(x - (GX[c] + 1)) <= 3 and abs(y - (GY[r] + 1)) <= 3     # у края область обрезает клетку


@pytest.mark.parametrize("box", [(323, 598, 380, 260), (400, 598, 520, 260), (323, 598, 594, 140)])
def test_cut_region_is_never_misaligned(lk, box):
    """Область режет сетку: часть клеток может отсутствовать, но ни одна не сдвигается и не выдумывается."""
    g = detect_grid(crop(lk, box))
    if not g.reliable:
        assert g.cells == [] and "ненадёжно" in g.warning
        return
    for (r, c), (x, y, *_s) in game_rects(g, box[0], box[1]).items():
        col = round((x - 1 - GX[0]) / 74)
        row = round((y - 1 - GY[0]) / 76)
        assert abs(x - (GX[col] + 1)) <= 3 and abs(y - (GY[row] + 1)) <= 3
        assert (row, col) in {(rr, cc) for rr in range(4) for cc in range(8)}
    assert {(c.row, c.col) for c in g.filled_cells()} <= {(r, c) for r in range(4) for c in range(8)}


# ---- сетка определяется ненадёжно -> распознавание не выполняется --------------------------------------
@pytest.mark.parametrize("name,box", [
    ("только список", (90, 560, 200, 170)),
    ("две сетки (партнёр + инвентарь)", (300, 190, 1400, 700)),
    ("текст и заголовок без сетки", (95, 560, 230, 40)),
])
def test_unreliable_grid_is_reported(lk, name, box):
    g = detect_grid(crop(lk, box))
    assert not g.reliable and g.cells == [] and "ненадёжно" in g.warning and g.filled_cells() == []


def test_noise_and_blank_images_are_unreliable():
    rnd = np.random.default_rng(0)
    for img in (rnd.integers(0, 255, (260, 594, 3), dtype=np.uint8), np.zeros((260, 594, 3), np.uint8),
                np.full((260, 594, 3), 120, np.uint8)):
        g = detect_grid(img)
        assert not g.reliable and g.cells == []


def test_engine_does_not_recognize_on_unreliable_grid(engine, lk):
    res = engine.fast_scan(crop(lk, (90, 560, 200, 170)))
    assert res.errors and "ненадёжно" in res.errors[0] and res.items == [] and res.cards == []
    assert engine.verify(res, None).items == []


def test_validate_grid_detects_overlaps_and_bad_sizes():
    g = Grid(region_size=(300, 200), pitch_x=74, pitch_y=76)
    g.cells = [Cell(0, 0, 0, 0, 72, 74), Cell(0, 1, 60, 0, 72, 74),            # пересечение по X
               Cell(1, 0, 0, 80, 72, 90)]                                        # другая высота
    probs = validate_grid(g)
    assert any("пересекаются" in p for p in probs) and any("высота" in p for p in probs)
    g.cells = [Cell(0, 0, 250, 0, 72, 74)]
    assert any("выходит за область" in p for p in validate_grid(g))


# ---- масштаб интерфейса ---------------------------------------------------------------------------
@pytest.mark.parametrize("sc", [0.9, 1.0, 1.1, 1.25, 1.5, 2.0])
def test_ui_scales_supported(lk, sc):
    im = cv2.resize(lk, None, fx=sc, fy=sc, interpolation=cv2.INTER_CUBIC) if sc != 1 else lk
    box = [int(round(v * sc)) for v in REGIONS["user_wide (список+заголовок+инвентарь)"]]
    g = detect_grid(crop(im, box))
    assert g.reliable and g.columns == 8 and {(c.row, c.col) for c in g.filled_cells()} == FILLED
    assert abs(g.pitch_x - 74 * sc) < 1.5 and abs(g.pitch_y - 76 * sc) < 2.0


@pytest.mark.parametrize("sc", [0.6, 0.75, 0.8])
@pytest.mark.parametrize("interp", [cv2.INTER_CUBIC, cv2.INTER_AREA, cv2.INTER_LINEAR])
def test_strongly_degraded_scales_are_safe(lk, sc, interp):
    """Сильно размытый ресайз: допустим честный отказ, но не «надёжная» сетка с неверными клетками."""
    im = cv2.resize(lk, None, fx=sc, fy=sc, interpolation=interp)
    box = [int(round(v * sc)) for v in REGIONS["user_wide (список+заголовок+инвентарь)"]]
    g = detect_grid(crop(im, box))
    if g.reliable:
        assert g.columns == 8 and {(c.row, c.col) for c in g.filled_cells()} == FILLED
    else:
        assert g.cells == [] and g.warning


# ---- совместимость с быстрым режимом ----------------------------------------------------------------------
def test_wide_region_end_to_end_matches_list(engine, lk):
    res = engine.scan(crop(lk, REGIONS["user_wide (список+заголовок+инвентарь)"]), crop(lk, (95, 565, 185, 175)))
    assert not res.errors
    known = {i.name: i.qty for i in res.items if i.status == "ok"}
    assert known == {"Мякоть солевика": 341, "Мякоть куборбуза": 23, "Мякоть лимонника": 17, "Мякоть сластены": 143}
    assert sum(i.amount for i in res.items if i.status == "ok") == 341 * 1500 + 23000 + 17000 + 143 * 8300
    assert sum(1 for c in res.cards if c.status == "unrecognized") == 2          # фиолетовый и зелёный — чужие


def test_cached_grid_equals_fresh_and_is_fast(lk):
    reg = crop(lk, REGIONS["user_wide (список+заголовок+инвентарь)"])
    d = GridDetector()
    fresh = d.detect(reg)
    t = time.perf_counter()
    for _ in range(50):
        cached = d.detect(reg)
    per = (time.perf_counter() - t) / 50 * 1000
    assert [c.rect for c in cached.cells] == [c.rect for c in fresh.cells] and per < 10
    # изменилась только область, где нет линий -> перепроверка линий замечает сдвиг сетки
    shifted = np.roll(reg, 5, axis=1)
    assert [c.rect for c in d.detect(shifted).cells] != [c.rect for c in fresh.cells] or not d.detect(shifted).reliable


# ---- диагностика -------------------------------------------------------------------------------------------------
def test_diagnostic_overlay_and_report_show_real_boundaries(lk):
    reg = crop(lk, REGIONS["user_wide (список+заголовок+инвентарь)"])
    g = detect_grid(reg)
    res = ScanResult(right_img=reg, grid=g)
    ov = render_overlay(res)
    assert ov.shape == reg.shape and not np.array_equal(ov, reg)
    for c in g.cells[:10]:                                          # граница каждой клетки действительно нарисована
        assert tuple(int(v) for v in ov[c.y, c.x + c.w // 2]) in {(170, 170, 170), (0, 165, 255)}
    rep = grid_report(res)
    assert rep["reliable"] and len(rep["cells"]) == 32 and rep["problems"] == []
    json.dumps(rep)                                                 # отчёт сериализуется (кадр сохраняется в problems/)
    bad = ScanResult(right_img=reg[:, :150].copy(), grid=detect_grid(reg[:, :150]))
    ov2 = render_overlay(bad)
    assert tuple(int(v) for v in ov2[100, 1]) == (60, 60, 255)      # красная рамка: «сетка ненадёжна»
    assert grid_report(bad)["reliable"] is False and grid_report(bad)["warning"]
